HEADDOWN - KEYBOARD REST MODE FOR WINDOWS 10/11
================================================
VERSION 1.1.1

QUICK START
1. Extract the HeadDown folder from the ZIP.
2. Double-click "Start HeadDown.bat".
3. Choose a silent timer length or turn the timer off.
4. Click LOCK KEYBOARD, then use the large mouse button to unlock it.

WHAT IT DOES
- Blocks normal keyboard input everywhere while locked.
- Keeps the mouse working so you can unlock it safely.
- Uses a compact, resizable window with scrolling on smaller displays.
- Includes a silent 1-180 minute heads-down timer.
- Wakes the display when the timer ends but keeps the keyboard locked.
- Can silence normal Windows notifications while locked.
- Can keep volume and playback media keys working while typing stays blocked.
- Automatically releases the keyboard if the app closes or crashes.
- Can switch to Windows Power Saver and dim the built-in display to 10%.
- Can turn the display off after 10 seconds. Move the mouse to wake it.
- Restores the original power plan and brightness when you unlock or close it.

BATTERY BUTTONS
- DIM TO 10%: Dims a laptop's built-in display.
- SCREEN OFF: Turns the display off immediately; move the mouse to wake it.
- RESTORE: Restores the power plan and brightness from when HeadDown opened.

IMPORTANT
- Keep a working mouse connected before locking the keyboard.
- Ctrl+Alt+Delete is handled directly by Windows and cannot be blocked by a
  normal app. If you open that screen, click Cancel with the mouse.
- External monitors often cannot be dimmed through Windows. SCREEN OFF and the
  power-plan controls will still work.
- This is a comfort tool, not a security lock. Use Win+L before HeadDown if you
  need to protect your files or account.
- Focus mode may not suppress critical system or priority notifications.
- No administrator access, installation, internet, or background service is used.

DISPLAY SIZE
- Drag any edge or corner to resize the app.
- If the window is made shorter, scroll down to reach the remaining controls.
- Maximize and restore work normally.
- If the interface cannot open, HeadDown displays the actual startup error.
- Version 1.1.1 fixes the "Cannot add type" error from the previous UI build.

If Windows blocks the script after download:
Right-click HeadDown.ps1, choose Properties, check Unblock, click Apply, and
then double-click Start HeadDown.bat again.
